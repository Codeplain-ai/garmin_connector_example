import sys
import os
from typing import List, Dict, Any

# Ensure we can import from src
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.garmin.client import GarminClient
from src.llm.client import LLMClient

# ANSI Color Codes for terminal UI
CLR_USER = "\033[94m"  # Blue
CLR_LLM = "\033[92m"   # Green
CLR_RESET = "\033[0m"
CLR_ERR = "\033[91m"   # Red

def run_chat_workflow(data_file: str = "garmin_data.json"):
    """
    Executes the chat workflow: loads data, initializes LLM, and starts chat loop.
    """
    print("--- Starting Garmin AI Coach ---")
    
    # 1. Initialize Garmin Client and Load Data
    garmin_client = GarminClient()
    if not os.path.exists(data_file):
        print(f"{CLR_ERR}Error: Activity data file '{data_file}' not found.{CLR_RESET}")
        print("Please run the data fetcher first to generate the activity log.")
        sys.exit(1)
        
    print(f"Loading activity history from {data_file}...")
    try:
        activities_data = garmin_client.load_from_file(data_file)
        if not activities_data:
            print(f"{CLR_ERR}Error: No activity data found in {data_file}.{CLR_RESET}")
            sys.exit(1)
    except Exception as e:
        print(f"{CLR_ERR}Failed to load activity data: {e}{CLR_RESET}")
        sys.exit(1)

    # 2. Initialize LLM Client
    print("Initializing LLM with your activity context...")
    try:
        llm_client = LLMClient()
        chat_session = llm_client.create_chat_session(activities_data)
    except Exception as e:
        print(f"{CLR_ERR}Failed to initialize AI Coach: {e}{CLR_RESET}")
        sys.exit(1)

    print(f"\n{CLR_LLM}Coach:{CLR_RESET} Hello! I've analyzed your running data from the last 180 days.")
    print("You can ask me about your pace trends, heart rate, lap breakdowns, or progress.")
    print("(Type 'exit' or 'quit' to end the session)")

    # 3. Interactive Loop
    while True:
        try:
            user_input = input(f"\n{CLR_USER}You: {CLR_RESET}").strip()
            
            if not user_input:
                continue
                
            if user_input.lower() in ['exit', 'quit']:
                print(f"\n{CLR_LLM}Coach:{CLR_RESET} Keep up the great work! Goodbye.")
                break

            print(f"\n{CLR_LLM}Coach: {CLR_RESET}", end="", flush=True)
            
            # Stream the response
            for chunk in llm_client.send_message(chat_session, user_input):
                print(chunk, end="", flush=True)
            print() # Newline after stream finishes

        except KeyboardInterrupt:
            print(f"\n\n{CLR_LLM}Coach:{CLR_RESET} Session interrupted. Happy running!")
            break
        except Exception as e:
            print(f"\n{CLR_ERR}An unexpected error occurred: {e}{CLR_RESET}")
            print("[DEBUG INFO] Please verify your network and GOOGLE_API_KEY.")
            sys.exit(1)

if __name__ == "__main__":
    run_chat_workflow()