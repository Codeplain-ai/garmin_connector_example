from .client import GarminClient

def main():
    """Main entry point for Garmin data retrieval."""
    client = GarminClient()
    client.login()
    
    print("[1/3] Authenticating with Garmin Connect...")
    client.login()

    print("[2/3] Fetching running activities and lap data (last 180 days)...")
    activities = client.fetch_running_activities(days=180)
    
    print(f"      Successfully retrieved {len(activities)} activities.")
    
    print("[3/3] Saving data to disk...")
    data_file = "garmin_data.json"
    client.save_to_file(activities, data_file)
    
    print(f"Workflow complete. Data stored in {data_file}.")

if __name__ == "__main__":
    main()