import sys
import os

# Ensure modules in src and app_flow are importable
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.garmin.main import main as fetch_main
from app_flow.chat_flow import run_chat_workflow

def run_application():
    """
    Main entry point for the Garmin Chat CLI.
    Orchestrates data fetching followed by the interactive AI chat session.
    """
    print("==========================================")
    print("   Garmin Connect AI Coach & Analytics    ")
    print("==========================================\n")

    # Step 1: Trigger the fetch workflow
    print("[SYSTEM] Starting data synchronization...")
    try:
        # This function handles login, fetching last 180 days, and saving to garmin_data.json
        fetch_main()
    except Exception as e:
        print(f"\n[FATAL ERROR] Data fetch workflow failed: {e}")
        print("[DEBUG] Check your GARMIN_EMAIL and GARMIN_PASSWORD environment variables.")
        sys.exit(1)

    print("\n[SYSTEM] Synchronization complete.")
    print("------------------------------------------\n")

    # Step 2: Trigger the chat workflow
    try:
        # This function loads the saved JSON and starts the Gemini chat session
        run_chat_workflow(data_file="garmin_data.json")
    except Exception as e:
        print(f"\n[FATAL ERROR] Chat workflow failed: {e}")
        print("[DEBUG] Check your GOOGLE_API_KEY and network connection.")
        sys.exit(1)

if __name__ == "__main__":
    try:
        run_application()
    except KeyboardInterrupt:
        print("\n\n[SYSTEM] Application terminated by user. Goodbye!")
        sys.exit(0)