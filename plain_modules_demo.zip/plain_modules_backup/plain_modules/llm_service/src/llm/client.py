import os
import sys
import json
from typing import Any, List, Dict
import google.generativeai as genai
from google.generativeai.types import RequestOptions

class LLMClient:
    """Service that interfaces with Google Gemini for analyzing Garmin data."""
    
    def __init__(self):
        self.api_key = os.getenv("GOOGLE_API_KEY")
        if not self.api_key:
            print("Error: GOOGLE_API_KEY environment variable is not set.")
            sys.exit(1)
        
        genai.configure(api_key=self.api_key)
        # Using the specific model version requested: gemini-3-flash-preview
        self.model_id = "gemini-1.5-flash" # Note: gemini-3 does not exist; using latest flash
        # However, to strictly follow instructions for "gemini-3-flash-preview":
        self.requested_model = "gemini-3-flash-preview"
        
        try:
            self.model = genai.GenerativeModel(model_name=self.requested_model)
        except Exception as e:
            print(f"Error initializing Gemini model '{self.requested_model}': {e}")
            sys.exit(1)

    def create_chat_session(self, activities_data: List[Dict[str, Any]]):
        """
        Creates a ChatSession with the Garmin activity data embedded in the system context.
        """
        context_payload = json.dumps(activities_data, indent=2)
        
        system_instruction = (
            "You are a specialized Garmin Running Coach and Data Analyst. "
            "The user's running data from the last 180 days is provided below in JSON format. "
            "This data includes activity summaries, heart rate metrics, and per-lap details. "
            "Your task is to answer questions specifically about these runs, laps, heart rate, "
            "and speed found in the data. Be precise, encouraging, and data-driven.\n\n"
            f"DATA:\n{context_payload}"
        )

        try:
            # We initialize the chat with the context as the first system-like message
            # because some versions of the SDK handle system_instruction differently,
            # this approach ensures the context is always in the history.
            chat = self.model.start_chat(history=[])
            # Send the initial context
            chat.send_message(system_instruction)
            return chat
        except Exception as e:
            print(f"Error starting chat session: {e}")
            sys.exit(1)

    def send_message(self, chat_session, user_input: str):
        """
        Sends a message to the existing session and returns a streaming response.
        
        Yields:
            str: Chunks of text from the model response.
        """
        try:
            response = chat_session.send_message(user_input, stream=True)
            for chunk in response:
                if chunk.text:
                    yield chunk.text
        except Exception as e:
            error_msg = f"\n[DEBUG INFO] API Error during streaming: {type(e).__name__}: {str(e)}"
            yield error_msg