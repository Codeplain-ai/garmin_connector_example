import sys
import os
import json
from .client import LLMClient

# ANSI Color Codes
CLR_USER = "\033[94m"  # Blue
CLR_LLM = "\033[92m"   # Green
CLR_RESET = "\033[0m"

def main():
    """Main entry point for the Garmin Chat Application."""
    data_file = "garmin_data.json"
    
    if not os.path.exists(data_file):
        print(f"Error: Data file '{data_file}' not found. Please run the Garmin fetcher first.")
        sys.exit(1)

    try:
        with open(data_file, 'r', encoding='utf-8') as f:
            activities = json.load(f)
    except Exception as e:
        print(f"Error loading '{data_file}': {e}")
        sys.exit(1)

    print("Initializing AI Coach with your Garmin data...")
    llm_client = LLMClient()
    chat_session = llm_client.create_chat_session(activities)
    
    print("\n--- Garmin Running Coach Chat ---")
    print("Type 'exit' or 'quit' to end the conversation.")
    
    while True:
        try:
            user_input = input(f"\n{CLR_USER}You: {CLR_RESET}")
            
            if user_input.lower() in ['exit', 'quit']:
                print("Goodbye!")
                break
            
            if not user_input.strip():
                continue

            print(f"\n{CLR_LLM}Coach: {CLR_RESET}", end="", flush=True)
            for chunk in llm_client.send_message(chat_session, user_input):
                print(chunk, end="", flush=True)
            print() # Final newline after stream ends
            
        except KeyboardInterrupt:
            print("\nSession ended.")
            break
        except Exception as e:
            print(f"\nError: {e}")

if __name__ == "__main__":
    main()