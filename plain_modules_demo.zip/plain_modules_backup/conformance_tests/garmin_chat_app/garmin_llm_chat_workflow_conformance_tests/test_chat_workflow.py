import subprocess
import os
import json
import time
import sys
import unittest

class TestChatWorkflow(unittest.TestCase):
    """
    Conformance Test: Verifies the chat workflow by executing the app as a subprocess.
    Tests initialization, data loading, LLM interaction with context, and graceful exit.
    """
    
    def setUp(self):
        self.data_file = "garmin_data.json"
        mock_data = [
            {
                "activityId": "123456789",
                "activityName": "Morning Run in the Park",
                "activityType": "running",
                "startTimeLocal": "2026-02-01 08:00:00",
                "distance": 5000.0,
                "duration": 1500.0,
                "averageHR": 155.0,
                "maxHR": 175.0,
                "averageSpeed": 3.33,
                "laps": [
                    {
                        "lapNumber": 1,
                        "startTime": "2026-02-01T08:00:00Z",
                        "distance": 5000.0,
                        "duration": 1500.0,
                        "averageSpeed": 3.33,
                        "averageHR": 155.0
                    }
                ]
            }
        ]
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(mock_data, f, indent=4)
        print(f"Created mock data at {self.data_file}")

    def tearDown(self):
        if os.path.exists(self.data_file):
            os.remove(self.data_file)

    def test_workflow_interactive_response(self):
        # Check for API Key
        if not os.getenv("GOOGLE_API_KEY"):
            self.skipTest("GOOGLE_API_KEY not set. Cannot run LLM conformance test.")

        # Prepare subprocess to run the chat flow
        # We use -u for unbuffered output to read streams correctly
        cmd = [sys.executable, "-u", "app_flow/chat_flow.py"]
        
        # Start the process
        process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=os.environ.copy()
        )

        try:
            # Step 1: Verify Initialization and Greeting
            output_buffer = ""
            start_time = time.time()
            greeting_found = False
            
            while time.time() - start_time < 30:
                line = process.stdout.readline()
                if line:
                    print(f"[APP STDOUT] {line.strip()}")
                    output_buffer += line
                    if "Coach:" in line and "Hello" in line:
                        greeting_found = True
                        break
                if process.poll() is not None:
                    break

            self.assertTrue(greeting_found, "The app did not initialize or greet the user correctly.")
            self.assertIn("Loading activity history", output_buffer, "App did not log loading of data file.")

            # Step 2: Send a data-specific query
            query = "What was the name and average heart rate of my last run in the data?\n"
            print(f"[TEST INPUT] Sending query: {query.strip()}")
            process.stdin.write(query)
            process.stdin.flush()

            # Step 3: Verify LLM Response (Streaming)
            response_buffer = ""
            start_time = time.time()
            data_match_found = False
            
            while time.time() - start_time < 60: # LLM can be slow
                line = process.stdout.readline()
                if line:
                    print(f"[APP STDOUT] {line.strip()}")
                    response_buffer += line
                    if "Morning Run" in response_buffer or "155" in response_buffer:
                        data_match_found = True
                        break
                if process.poll() is not None:
                    break

            self.assertTrue(data_match_found, f"LLM response did not reference the provided data. Buffer: {response_buffer}")

            # Step 4: Terminate Session
            print("[TEST INPUT] Sending 'exit'")
            process.stdin.write("exit\n")
            process.stdin.flush()

            # Step 5: Verify Graceful Exit
            goodbye_found = False
            start_time = time.time()
            while time.time() - start_time < 10:
                line = process.stdout.readline()
                if line:
                    print(f"[APP STDOUT] {line.strip()}")
                    if "Goodbye" in line:
                        goodbye_found = True
                if process.poll() is not None:
                    break
            
            self.assertTrue(goodbye_found, "App did not show a goodbye message on exit.")
            self.assertEqual(process.wait(timeout=5), 0, "Process did not exit with code 0.")

        finally:
            if process.poll() is None:
                process.kill()

if __name__ == "__main__":
    unittest.main()