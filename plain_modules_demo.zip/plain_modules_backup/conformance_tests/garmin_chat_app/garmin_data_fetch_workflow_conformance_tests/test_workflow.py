import os
import subprocess
import json
import unittest
import sys

class TestWorkflow(unittest.TestCase):
    """
    Validates the data fetch workflow by executing the garmin.main module.
    This test verifies progress updates, file creation, and data structure 
    integrity without mocking API calls or importing internal code.
    """

    def test_workflow_execution_and_persistence(self):
        # 1. Environment Pre-check
        email = os.getenv("GARMIN_EMAIL")
        password = os.getenv("GARMIN_PASSWORD")
        
        if not email or not password:
            self.fail("GARMIN_EMAIL and GARMIN_PASSWORD environment variables must be set.")

        data_file = "garmin_data.json"
        if os.path.exists(data_file):
            os.remove(data_file)

        # 2. Execution of the garmin data fetch workflow
        # We run the module as a subprocess to test the actual application entry point
        # as required by the functionality description.
        print("\nExecuting Garmin Data Fetch Workflow...")
        
        # Use the current python interpreter to run the module
        process = subprocess.Popen(
            [sys.executable, "-m", "src.garmin.main"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=os.environ.copy()
        )

        try:
            stdout, stderr = process.communicate(timeout=120)
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            self.fail("Workflow execution timed out after 120 seconds.")

        # 3. Debug Output
        print("--- STDOUT ---")
        print(stdout)
        print("--- STDERR ---")
        print(stderr)

        # 4. Assertions on Functionality
        self.assertEqual(process.returncode, 0, f"Workflow failed with return code {process.returncode}")

        # Verify progress updates were displayed to the user
        expected_updates = [
            "Authenticating with Garmin Connect",
            "Fetching running activities",
            "Saving data to disk",
            "Workflow complete"
        ]
        for update in expected_updates:
            self.assertIn(update.lower(), stdout.lower(), f"Missing progress update: '{update}'")

        # Verify persistence
        self.assertTrue(os.path.exists(data_file), f"Expected data file '{data_file}' was not created.")

        # 5. Data Integrity Verification
        try:
            with open(data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            self.assertIsInstance(data, list, "Data file should contain a list of activities.")
            
            # If the account has activities, verify the structure of the first one
            if len(data) > 0:
                activity = data[0]
                required_keys = ["activityId", "activityType", "laps"]
                for key in required_keys:
                    self.assertIn(key, activity, f"Activity missing required key: {key}")
                
                # Verify that laps were fetched and saved
                self.assertIsInstance(activity["laps"], list, "Laps should be a list.")
                # Note: We assume the running activity has at least one lap (standard Garmin behavior)
                self.assertGreater(len(activity["laps"]), 0, f"Activity {activity.get('activityId')} has no laps.")
                
                # Verify lap structure
                lap = activity["laps"][0]
                self.assertIn("lapNumber", lap)
                self.assertIn("distance", lap)
                
                print(f"Verified {len(data)} activities. Sample activity ID: {activity.get('activityId')}")
            else:
                print("Warning: No running activities found in the last 180 days for this account.")

        except json.JSONDecodeError:
            self.fail("The generated 'garmin_data.json' is not a valid JSON file.")
        except Exception as e:
            self.fail(f"An error occurred during data verification: {e}")
        finally:
            # Cleanup (Optional: keep for debugging if needed)
            if os.path.exists(data_file):
                 print(f"Test complete. Persistence file {data_file} verified.")

if __name__ == "__main__":
    unittest.main()