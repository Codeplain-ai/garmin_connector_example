import unittest
import subprocess
import os
import sys
import time
import signal

class TestCliOrchestration(unittest.TestCase):
    """
    Conformance tests for the CLI orchestration flow.
    Verifies that garmin_chat.py correctly sequences data fetching and the chat session.
    """

    def setUp(self):
        self.data_file = "garmin_data.json"
        self.target_script = "garmin_chat.py"
        # Ensure credentials are present in environment
        self.email = os.getenv("GARMIN_EMAIL")
        self.password = os.getenv("GARMIN_PASSWORD")
        self.api_key = os.getenv("GOOGLE_API_KEY")

        if not all([self.email, self.password, self.api_key]):
            self.fail("Required environment variables (GARMIN_EMAIL, GARMIN_PASSWORD, GOOGLE_API_KEY) are missing.")

    def test_cli_orchestration_flow(self):
        """
        Verify that executing garmin_chat.py initiates fetching followed by chat.
        We simulate a 'quit' command to exit the interactive loop.
        """
        print(f"\n[TEST] Running orchestration test for {self.target_script}...")
        
        # Start the process. We use a pipe for stdin to send 'quit'
        # We increase timeout because Garmin API and LLM can be slow.
        process = subprocess.Popen(
            [sys.executable, self.target_script],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1
        )

        output_log = []
        sync_complete = False
        coach_initialized = False
        
        start_time = time.time()
        timeout = 180  # 3 minutes total for fetch and first prompt

        try:
            # Monitor output to check for sequence
            while True:
                if time.time() - start_time > timeout:
                    process.kill()
                    self.fail(f"Test timed out. Output so far:\n{''.join(output_log)}")

                line = process.stdout.readline()
                if not line:
                    break
                
                output_log.append(line)
                print(f"  [STDOUT] {line.strip()}")

                if "Synchronization complete" in line:
                    sync_complete = True
                
                if "Initializing LLM with your activity context" in line:
                    coach_initialized = True

                # Look for the prompt or the greeting to send the exit command
                if "Coach:" in line and "Hello!" in line:
                    print("  [TEST] Detected Coach greeting. Sending 'quit' command...")
                    process.stdin.write("quit\n")
                    process.stdin.flush()
                    break

            # Wait for process to finish
            stdout, stderr = process.communicate(timeout=30)
            output_log.append(stdout)
            
            print(f"  [STDERR] {stderr}")

            # Assertions
            self.assertTrue(sync_complete, "CLI did not report synchronization completion.")
            self.assertTrue(os.path.exists(self.data_file), f"Data file '{self.data_file}' was not created.")
            self.assertTrue(coach_initialized, "CLI did not transition to LLM initialization.")
            self.assertIn("Goodbye", "".join(output_log), "CLI did not terminate gracefully after 'quit'.")
            
            print("[TEST] Orchestration flow verified successfully.")

        except Exception as e:
            process.kill()
            self.fail(f"An error occurred during CLI execution: {e}")

if __name__ == "__main__":
    unittest.main()