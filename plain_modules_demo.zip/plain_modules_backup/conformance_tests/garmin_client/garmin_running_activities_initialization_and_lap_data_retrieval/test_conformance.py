import unittest
import os
import subprocess
import sys
from datetime import datetime, timedelta

class TestGarminRunningActivitiesConformance(unittest.TestCase):
    """
    Conformance tests for GarminClient functionality.
    These tests verify the behavior of the application by executing the code 
    and inspecting the data structures returned by the logic, ensuring no mocks are used.
    """

    @classmethod
    def setUpClass(cls):
        # Verify environment variables are present as per :plainFunctionality:
        cls.email = os.getenv("GARMIN_EMAIL")
        cls.password = os.getenv("GARMIN_PASSWORD")
        
        if not cls.email or not cls.password:
            raise unittest.SkipTest("GARMIN_EMAIL or GARMIN_PASSWORD not set. Skipping conformance tests.")

        # Import the client dynamically to avoid hard-coded internal dependencies in the test structure
        # but since we must use the provided implementation code, we import the GarminClient.
        sys.path.append(os.path.join(os.getcwd(), 'src'))
        from garmin.client import GarminClient
        
        cls.client = GarminClient()
        cls.client.login()
        print("Successfully authenticated with Garmin Connect.")
        
        # Fetch activities once for all tests to respect API limits and performance
        print("Fetching activities for the last 180 days...")
        cls.activities = cls.client.fetch_running_activities(days=180)
        print(f"Retrieved {len(cls.activities)} activities for testing.")

    def test_verify_running_activity_type_filtering(self):
        """
        Test 1: VerifyRunningActivityTypeFiltering
        Asserts that every retrieved activity has 'running' in the activityType.
        """
        self.assertGreater(len(self.activities), 0, "No activities found. Ensure the account has running data.")
        
        for activity in self.activities:
            activity_type = activity.activityType.lower()
            print(f"Checking Activity ID {activity.activityId}: Type='{activity_type}'")
            self.assertIn("running", activity_type, 
                          f"Activity {activity.activityId} has type '{activity_type}', which does not contain 'running'.")
            
            # Verify LapData requirement: For every retrieved ActivitySummary, obtain associated LapData.
            # This is checked here as part of the data structure integrity.
            self.assertIsNotNone(activity.laps, f"Laps list is None for activity {activity.activityId}")
            print(f"  - Laps found: {len(activity.laps)}")

    def test_verify_activity_date_range_constraint(self):
        """
        Test 2: VerifyActivityDateRangeConstraint
        Asserts that no activity is older than 180 days.
        """
        self.assertGreater(len(self.activities), 0, "No activities found to verify date range.")
        
        now = datetime.now()
        limit_date = now - timedelta(days=180)
        
        for activity in self.activities:
            # startTimeLocal format is typically YYYY-MM-DDTHH:MM:SS.0
            # We handle common Garmin date formats
            try:
                # Stripping potential decimals from seconds if present
                date_str = activity.startTimeLocal.split('.')[0]
                if 'T' in date_str:
                    act_date = datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S")
                else:
                    act_date = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
            except ValueError as e:
                self.fail(f"Failed to parse date '{activity.startTimeLocal}' for activity {activity.activityId}: {e}")

            print(f"Checking Activity ID {activity.activityId}: Date='{act_date}'")
            self.assertGreaterEqual(act_date, limit_date, 
                                    f"Activity {activity.activityId} dated {act_date} is older than 180 days.")

    def test_verify_minimum_activity_count(self):
        """
        Test 3: VerifyMinimumActivityCount (Acceptance Test)
        Asserts that there is more than 1 activity retrieved for the period of 180 days.
        """
        count = len(self.activities)
        print(f"Verifying activity count: {count} found.")
        self.assertGreater(count, 1, 
                           f"Retrieved {count} activities, but expected more than 1 running activity "
                           "in the last 180 days. Ensure the Garmin account contains multiple "
                           "running activities within this timeframe.")

    def test_verify_lap_data_presence(self):
        """
        Test 4: VerifyLapDataPresence (Acceptance Test)
        The GarminClient should return a list of ActivitySummary objects. 
        Each ActivitySummary must contain a non-empty list of LapData if laps were recorded.
        """
        self.assertGreater(len(self.activities), 0, "No activities found to verify lap data.")

        for activity in self.activities:
            print(f"Verifying LapData for Activity ID {activity.activityId} ({activity.activityName})")
            
            # Verify it's the correct list type
            self.assertIsInstance(activity.laps, list, 
                                  f"Activity {activity.activityId} 'laps' field is not a list. Type: {type(activity.laps)}")
            
            # Garmin running activities always have at least one lap (the activity itself) 
            # unless there's a data retrieval failure.
            lap_count = len(activity.laps)
            print(f"  - Lap count: {lap_count}")
            
            self.assertGreater(lap_count, 0, 
                               f"Activity {activity.activityId} ('{activity.activityName}') has an empty laps list. "
                               "Garmin running activities are expected to contain at least one lap.")
            
            # Verify the content of the laps
            from garmin.models import LapData
            for lap in activity.laps:
                self.assertIsInstance(lap, LapData, 
                                      f"Object in laps list for activity {activity.activityId} is not a LapData instance.")

    def test_verify_heart_rate_data_presence(self):
        """
        Test 5: VerifyHeartRateDataPresence (Acceptance Test)
        Asserts that heart rate data is present for at least one activity.
        """
        self.assertGreater(len(self.activities), 0, "No activities found to verify heart rate data.")
        
        activities_with_hr = []
        for activity in self.activities:
            hr = activity.averageHR
            print(f"Checking HR for Activity {activity.activityId}: averageHR={hr}")
            if hr is not None and hr > 0:
                activities_with_hr.append(activity.activityId)
        
        hr_count = len(activities_with_hr)
        print(f"Found {hr_count} activities with valid heart rate data.")
        
        self.assertGreater(hr_count, 0, 
                           "None of the retrieved running activities contain heart rate data. "
                           "Expected at least one activity to have an averageHR > 0. "
                           "Please verify if the Garmin device used supports HR or if HR recording was enabled.")

if __name__ == "__main__":
    unittest.main()