import os
import json
import unittest
import subprocess
from typing import Dict, List, Any

# Test data representing an ActivitySummary and LapData
MOCK_GARMIN_DATA: List[Dict[str, Any]] = [
    {
        "activityId": "123456789",
        "activityName": "Morning Interval Run",
        "activityType": "running",
        "startTimeLocal": "2024-01-15 08:00:00",
        "distance": 5000.0,
        "duration": 1500.0,
        "averageHR": 155.0,
        "maxHR": 175.0,
        "averageSpeed": 3.33,
        "laps": [
            {
                "lapNumber": 1,
                "startTime": "2024-01-15T08:00:00Z",
                "distance": 1000.0,
                "duration": 300.0,
                "averageSpeed": 3.33,
                "averageHR": 140.0
            },
            {
                "lapNumber": 2,
                "startTime": "2024-01-15T08:05:00Z",
                "distance": 1000.0,
                "duration": 280.0,
                "averageSpeed": 3.57,
                "averageHR": 170.0
            }
        ]
    }
]

class TestLLMChat(unittest.TestCase):
    """Conformance tests for the LLM Chat functionality."""

    def test_llm_context_initialization_and_query(self):
        """
        Test 1: test_llm_context_initialization_and_query
        Verifies the LLMClient initialization, context loading from file, 
        and real API interaction.
        """
        data_file = "garmin_data.json"
        api_key = os.getenv("GOOGLE_API_KEY")

        # Pre-test checks
        self.assertTrue(api_key, "GOOGLE_API_KEY environment variable is not set. Cannot run conformance test.")
        
        print(f"\nSetting up test data in {data_file}...")
        with open(data_file, "w", encoding="utf-8") as f:
            json.dump(MOCK_GARMIN_DATA, f)

        try:
            # We test the functionality by executing the llm service main module
            print("Starting LLM Service process...")
            cmd = ["python3", "-m", "src.llm.main"]
            
            # We use a pipe to send the query and 'exit' command
            user_input = "What was my max heart rate in the Morning Interval Run and the average HR of lap 2?\nexit\n"
            
            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=os.environ.copy()
            )

            print("Sending query to LLM and waiting for response (this may take time)...")
            stdout, stderr = process.communicate(input=user_input, timeout=60)

            print("--- LLM SERVICE STDOUT ---")
            print(stdout)
            print("--- LLM SERVICE STDERR ---")
            print(stderr)

            # Assertions
            self.assertEqual(process.returncode, 0, f"Process failed with exit code {process.returncode}")
            
            output_lower = stdout.lower()
            
            # Check if the response contains the specific data from the JSON context
            self.assertIn("175", output_lower, "LLM response did not reference the max heart rate (175) from context.")
            self.assertIn("170", output_lower, "LLM response did not reference lap 2 heart rate (170) from context.")
            self.assertIn("coach:", output_lower, "Application did not output a 'Coach' response.")

            print("Conformance Test Passed: LLM successfully analyzed the provided JSON context.")

        except subprocess.TimeoutExpired:
            process.kill()
            self.fail("The LLM service took too long to respond (Timeout).")
        except Exception as e:
            self.fail(f"Conformance test encountered an error: {e}")
        finally:
            # Cleanup
            if os.path.exists(data_file):
                os.remove(data_file)

if __name__ == "__main__":
    # Allow manual execution for debugging
    test_llm_context_initialization_and_query()