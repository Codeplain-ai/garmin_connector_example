import unittest
import os
import sys
import json
import time

# Robust path injection: 
# The test is in <ROOT>/conformance_tests/llm_service/process_user_message_streaming_response/test_llm_streaming.py
# The src is in <ROOT>/src
# We need to add <ROOT>/src to sys.path
current_file_path = os.path.abspath(__file__)
conformance_tests_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_file_path))))
src_path = os.path.join(conformance_tests_dir, "src")

if src_path not in sys.path:
    sys.path.insert(0, src_path)

# Verify path for debugging
print(f"[DEBUG] Current File: {current_file_path}")
print(f"[DEBUG] Calculated SRC Path: {src_path}")
print(f"[DEBUG] Directory content of SRC: {os.listdir(src_path) if os.path.exists(src_path) else 'NOT FOUND'}")

try:
    from llm.client import LLMClient
except ImportError as e:
    print(f"[DEBUG] Failed to import from llm.client: {e}")
    # Fallback/Diagnostic: check if it's accessible as src.llm.client
    try:
        # If the environment treats 'src' as a package
        parent_of_src = os.path.dirname(src_path)
        if parent_of_src not in sys.path:
            sys.path.insert(0, parent_of_src)
        from src.llm.client import LLMClient
        print("[DEBUG] Imported successfully using 'src.llm.client'")
    except ImportError as e2:
        print(f"[DEBUG] Failed to import from src.llm.client: {e2}")
        raise e

class TestLLMStreamingResponse(unittest.TestCase):
    """
    Conformance tests for LLM message processing and streaming.
    Tests focus on the functionality of streaming responses and conversation context.
    """

    @classmethod
    def setUpClass(cls):
        # Validate environment
        if not os.getenv("GOOGLE_API_KEY"):
            raise unittest.SkipTest("GOOGLE_API_KEY not set. Skipping LLM conformance tests.")
        
        # Load the dummy data for context using absolute path
        data_path = os.path.join(os.path.dirname(__file__), "garmin_data.json")
        try:
            with open(data_path, "r") as f:
                cls.activities = json.load(f)
        except FileNotFoundError:
            print(f"[DEBUG] Data file not found at: {data_path}")
            # Fallback for some test runners
            data_path = "garmin_data.json"
            with open(data_path, "r") as f:
                cls.activities = json.load(f)

    def test_llm_streaming_response_flow(self):
        """
        Verify that the LLM returns a streaming response and correctly identifies
        specific metrics from the provided activity JSON.
        """
        print("\nRunning Test: test_llm_streaming_response_flow")
        client = LLMClient()
        session = client.create_chat_session(self.activities)
        
        query = "What was the average heart rate of my 'Morning Interval Run'?"
        chunks = []
        
        print(f"Sending query: {query}")
        # Metrics: avg HR in JSON is 160.0
        start_time = time.time()
        
        # The implementation of send_message is a generator yielding chunks
        for chunk in client.send_message(session, query):
            if chunk:
                print(f"Chunk received: {repr(chunk)}")
                chunks.append(chunk)
        
        duration = time.time() - start_time
        full_response = "".join(chunks)
        print(f"Full Response: {full_response}")
        print(f"Stream duration: {duration:.2f}s, Chunk count: {len(chunks)}")

        # Conformance Checks
        self.assertGreater(len(chunks), 1, "The response should be streamed in multiple chunks.")
        self.assertIn("160", full_response, "The LLM response should contain the average HR '160' from the data.")
        self.assertLess(duration, 45, "The LLM response took too long (timeout > 45s).")

    def test_llm_multi_turn_conversation_consistency(self):
        """
        Verify the LLM maintains history and context across multiple messages.
        """
        print("\nRunning Test: test_llm_multi_turn_conversation_consistency")
        client = LLMClient()
        session = client.create_chat_session(self.activities)

        # Turn 1
        query1 = "In my Morning Interval Run, what was my average heart rate?"
        print(f"Query 1: {query1}")
        resp1 = "".join([c for c in client.send_message(session, query1)])
        print(f"Response 1: {resp1}")
        self.assertIn("160", resp1)

        # Turn 2: Follow-up relying on history
        query2 = "Is that value (the heart rate) considered high for a 30-year-old?"
        print(f"Query 2: {query2}")
        resp2 = "".join([c for c in client.send_message(session, query2)])
        print(f"Response 2: {resp2}")

        # Check for contextual keywords
        keywords = ["heart rate", "bpm", "intensity", "beats", "zone", "high", "normal"]
        found_context = any(word in resp2.lower() for word in keywords)
        
        self.assertTrue(found_context, f"The second response did not seem to relate to the previous heart rate context. Response: {resp2}")
        self.assertNotIn("garmin_data.json", resp2, "The model should use history, not just repeat the raw JSON file name.")

if __name__ == "__main__":
    unittest.main()