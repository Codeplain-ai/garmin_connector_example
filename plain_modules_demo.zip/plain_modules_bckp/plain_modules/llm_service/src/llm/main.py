import sys
from .client import LLMClient
from src.garmin.client import GarminClient

def main():
    """Main entry point for the Garmin Chat interface."""
    garmin_client = GarminClient()
    data_file = "garmin_data.json"
    
    # Check if data exists, if not, prompt user to run the garmin collector first
    try:
        activities = garmin_client.load_from_file(data_file)
    except SystemExit:
        print("Please run 'python -m src.garmin.main' first to collect your Garmin data.")
        sys.exit(1)

    print("Initializing AI Coach with your Garmin data...")
    llm_client = LLMClient()
    chat_session = llm_client.create_chat_session(activities)
    
    print("\n--- Garmin AI Chat Session Started ---")
    print("Type 'exit' or 'quit' to end the conversation.\n")

    while True:
        try:
            user_message = llm_client.get_user_input()
            
            if user_message.lower() in ['exit', 'quit']:
                print("Closing chat. Keep up the training!")
                break
                
            if not user_message.strip():
                continue

            response_stream = chat_session.send_message(user_message, stream=True)
            llm_client.print_llm_response(response_stream)
            
        except KeyboardInterrupt:
            print("\nChat interrupted.")
            break
        except Exception as e:
            print(f"\033[91mError during chat: {e}\033[0m")
            sys.exit(1)

if __name__ == "__main__":
    main()