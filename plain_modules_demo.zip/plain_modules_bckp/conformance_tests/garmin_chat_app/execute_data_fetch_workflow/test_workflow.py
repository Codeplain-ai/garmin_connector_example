import os
import json
import subprocess
import unittest
import sys

class TestGarminWorkflow(unittest.TestCase):
    def setUp(self):
        self.data_file = "garmin_data.json"
        if os.path.exists(self.data_file):
            os.remove(self.data_file)

    def tearDown(self):
        if os.path.exists(self.data_file):
            os.remove(self.data_file)

    def test_workflow_execution_and_persistence(self):
        """
        Test 1: test_workflow_execution_and_persistence
        Executes the workflow and verifies the persistence of garmin_data.json.
        """
        # Ensure environment variables are present (credentials must be provided by the environment)
        self.assertTrue(os.getenv("GARMIN_EMAIL"), "GARMIN_EMAIL env var is missing")
        self.assertTrue(os.getenv("GARMIN_PASSWORD"), "GARMIN_PASSWORD env var is missing")
        
        # Run the workflow script as a subprocess to test the application flow
        print("\nRunning Garmin Data Fetch Workflow...")
        process = subprocess.run(
            [sys.executable, "-m", "src.app_flow.garmin_flow"],
            capture_output=True,
            text=True,
            timeout=300 # Allowing time for API calls
        )

        # Debug output
        print(process.stdout)
        if process.stderr:
            print(f"Error output: {process.stderr}", file=sys.stderr)

        # Verify workflow completed successfully
        self.assertEqual(process.returncode, 0, f"Workflow failed with return code {process.returncode}")
        
        # Verify file creation and content
        self.assertTrue(os.path.exists(self.data_file), "garmin_data.json was not created")
        
        with open(self.data_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        self.assertIsInstance(data, list, "Data file should contain a JSON array")
        
        # If there is data, check the structure of the first entry
        if len(data) > 0:
            entry = data[0]
            required_keys = ['activityId', 'activityType', 'laps', 'distance']
            for key in required_keys:
                self.assertIn(key, entry, f"Missing key '{key}' in persisted activity data")
            
            print(f"Verified {len(data)} activities in {self.data_file}")
        else:
            print("Warning: No activities were found for the account in the last 180 days, but workflow finished.")

    def test_workflow_progress_reporting(self):
        """
        Test 2: test_workflow_progress_reporting
        Verifies that the workflow provides real-time progress updates to the console.
        """
        # Run the workflow and capture output
        process = subprocess.run(
            [sys.executable, "-m", "src.app_flow.garmin_flow"],
            capture_output=True,
            text=True,
            timeout=300
        )

        output = process.stdout
        
        # Define expected progress indicators
        indicators = [
            "Garmin Data Fetch Workflow Started",
            "Authenticating with Garmin Connect",
            "Fetching running activities",
            "Successfully saved"
        ]
        
        # We check for these indicators. 'Processing activity:' is only present if activities exist.
        for indicator in indicators:
            self.assertIn(indicator, output, f"Progress indicator '{indicator}' not found in console output")
        
        # If activities were found, check for the specific processing string
        if "Successfully retrieved" in output and "retrieved 0 activities" not in output:
            self.assertIn("Processing activity:", output, "Expected activity processing updates were missing")

        print("Progress reporting verification successful.")

if __name__ == "__main__":
    unittest.main()