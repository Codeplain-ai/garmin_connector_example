import subprocess
import os
import json
import unittest
import sys

class TestChatWorkflow(unittest.TestCase):
    def setUp(self):
        self.data_file = "garmin_data.json"
        mock_data = [
            {
                "activityId": "12345678",
                "activityName": "Test Evening Run",
                "activityType": "running",
                "startTimeLocal": "2026-02-01 18:00:00",
                "distance": 5000.0,
                "duration": 1500.0,
                "averageHR": 155.0,
                "maxHR": 170.0,
                "averageSpeed": 3.33,
                "laps": [
                    {
                        "lapNumber": 1,
                        "startTime": "2026-02-01T18:00:00Z",
                        "distance": 5000.0,
                        "duration": 1500.0,
                        "averageSpeed": 3.33,
                        "averageHR": 155.0
                    }
                ]
            }
        ]
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(mock_data, f)

    def tearDown(self):
        if os.path.exists(self.data_file):
            os.remove(self.data_file)

    def test_chat_workflow_integration_and_llm_grounding(self):
        """
        Test 1: test_chat_workflow_integration_and_llm_grounding
        Verifies the chat workflow by running the module as a subprocess.
        """
        # Check for API Key
        if not os.getenv("GOOGLE_API_KEY"):
            self.fail("GOOGLE_API_KEY environment variable is missing. Cannot run live LLM tests.")

        # Prepare inputs: A query about specific data and then exit
        # Query: What was the average heart rate of my run on February 1st? (Expect ~155)
        inputs = "What was my average heart rate on my Test Evening Run?\nexit\n"
        
        print("\n--- Starting Chat Workflow Subprocess ---")
        
        try:
            # We run the module directly to test the entry point and interactive loop
            process = subprocess.Popen(
                [sys.executable, "-m", "src.app_flow.chat_flow"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=os.environ
            )
            
            # Send inputs and wait for completion (timeout 60s for LLM response)
            stdout, stderr = process.communicate(input=inputs, timeout=60)
            
            print("STDOUT Output:\n", stdout)
            if stderr:
                print("STDERR Output:\n", stderr)

            # Assertions
            self.assertEqual(process.returncode, 0, f"Workflow failed with return code {process.returncode}")
            self.assertIn("Loading activity data", stdout)
            self.assertIn("Loaded 1 activities", stdout)
            self.assertIn("Coach:", stdout)
            self.assertIn("Closing chat", stdout)
            
            # Grounding check: The LLM should mention the heart rate from our mock data
            self.assertIn("155", stdout, "The LLM response did not contain the expected heart rate (155) from the data file.")

        except subprocess.TimeoutExpired:
            process.kill()
            self.fail("The chat workflow timed out. LLM response might be too slow or loop didn't exit.")

if __name__ == "__main__":
    unittest.main()