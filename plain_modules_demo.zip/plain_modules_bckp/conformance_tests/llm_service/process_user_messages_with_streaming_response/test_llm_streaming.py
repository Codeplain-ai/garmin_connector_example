import os
import json
import unittest
import subprocess
import sys
from typing import List, Dict, Any

# Conformance Test for llm_service: Process user messages with streaming
# This test verifies that the system can process natural language queries 
# against provided Garmin data and returns a streaming response.

def create_mock_garmin_data(filename: str):
    """Creates a dummy garmin_data.json for the LLM context."""
    data = [
        {
            "activityId": "999999",
            "activityName": "High Altitude Tempo Run",
            "activityType": "running",
            "startTimeLocal": "2026-01-20 08:00:00",
            "distance": 10500.0,
            "duration": 3000.0,
            "averageHR": 155.0,
            "maxHR": 175.0,
            "averageSpeed": 3.5,
            "laps": [
                {
                    "lapNumber": 1,
                    "startTime": "2026-01-20T08:00:00Z",
                    "distance": 5000.0,
                    "duration": 1500.0,
                    "averageSpeed": 3.33,
                    "averageHR": 150.0
                },
                {
                    "lapNumber": 2,
                    "startTime": "2026-01-20T08:25:00Z",
                    "distance": 5500.0,
                    "duration": 1500.0,
                    "averageSpeed": 3.66,
                    "averageHR": 160.0
                }
            ]
        }
    ]
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)
    print(f"Created mock data file: {filename}")

class TestLLMStreaming(unittest.TestCase):
    """
    Validates :codeplain::Functionality: 'Process user messages' by verifying 
    the streaming capability and data grounding of the LLM response.
    """

    def setUp(self):
        self.data_file = "garmin_data.json"
        self.exec_file = "exec_test.py"
        create_mock_garmin_data(self.data_file)

    def tearDown(self):
        for f in [self.data_file, self.exec_file]:
            if os.path.exists(f):
                os.remove(f)

    def test_llm_streaming_response_functionality(self):
        # Ensure API key is present
        if not os.getenv("GOOGLE_API_KEY"):
            self.fail("GOOGLE_API_KEY environment variable is not set.")

        # We use the src.llm.main entry point but simulate user interaction.
    # To test the internal "Process user messages" functionality specifically 
    # without mocking and ensuring streaming, we use a python script that
    # imports the logic as defined in the project structure.
    
        test_script = f"""
import sys
import os
# Add src to path
sys.path.append(os.getcwd())

from src.llm.client import LLMClient
import json

def run_test():
    with open("{self.data_file}", "r") as f:
        activities = json.load(f)
    
    client = LLMClient()
    # Minimal thinking/conciseness is requested via system prompt in the implementation
    session = client.create_chat_session(activities)
    
    query = "Summarize my High Altitude Tempo Run. Mention the total distance."
    print(f"Querying: {{query}}")
    
    # Requirement: Return the text response from the model with a streaming response.
    response_stream = session.send_message(query, stream=True)
    
    full_text = ""
    chunk_count = 0
    
    print("Coach: ", end="", flush=True)
    for chunk in response_stream:
        if chunk.text:
            print(chunk.text, end="", flush=True)
            full_text += chunk.text
            chunk_count += 1
    print("\\n")
    
    # Verification
    assert chunk_count > 0, "Response was not streamed (no chunks received)"
    assert any(x in full_text for x in ["10.5", "10,5", "10500"]), "Response missing distance context"
    assert "High Altitude" in full_text, "Response missing activity name context"
    print("Streaming verification successful.")

if __name__ == '__main__':
    run_test()
"""
        
        with open(self.exec_file, "w") as f:
            f.write(test_script)

        # LLM calls can be slow, 60s timeout
        result = subprocess.run(
            [sys.executable, self.exec_file],
            capture_output=True,
            text=True,
            timeout=60,
            env=os.environ
        )
        
        print("STDOUT:", result.stdout)
        print("STDERR:", result.stderr)
        
        self.assertEqual(result.returncode, 0, f"LLM Processing failed with exit code {result.returncode}")
        self.assertIn("Streaming verification successful", result.stdout)

if __name__ == "__main__":
    unittest.main()