import os
import json
import unittest
from src.llm.client import LLMClient
from src.garmin.client import GarminClient

class TestLLMConformance(unittest.TestCase):
    """
    Conformance tests for LLM functionality using the standard unittest framework.
    Requirements: LLM responses take time, no mocking, minimal thinking level.
    """

    @classmethod
    def setUpClass(cls):
        cls.data_file = "garmin_data.json"
        cls.mock_data = [
            {
                "activityId": "12345",
                "activityName": "Morning Interval Run",
                "activityType": "running",
                "startTimeLocal": "2024-01-01 08:00:00",
                "distance": 5000.0,
                "duration": 1500.0,
                "averageHR": 145.0,
                "maxHR": 170.0,
                "averageSpeed": 3.33,
                "laps": [
                    {
                        "lapNumber": 1,
                        "startTime": "2024-01-01T08:00:00Z",
                        "distance": 1000.0,
                        "duration": 300.0,
                        "averageSpeed": 3.33,
                        "averageHR": 140.0
                    }
                ]
            }
        ]

    def setUp(self):
        """Creates a temporary garmin_data.json file before each test."""
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(self.mock_data, f)

    def tearDown(self):
        """Removes the temporary file after each test."""
        if os.path.exists(self.data_file):
            os.remove(self.data_file)

    def test_llm_context_initialization_and_query(self):
        """
        Test 1: Verifies that the LLM correctly interprets the JSON context 
        provided in garmin_data.json by asking for a specific metric.
        """
        print(f"\nRunning Test 1: LLM Context Initialization with {self.data_file}")
        
        # 1. Load data using the implementation's logic
        garmin_client = GarminClient()
        activities = garmin_client.load_from_file(self.data_file)
        
        # 2. Initialize LLM with context
        llm_client = LLMClient()
        chat_session = llm_client.create_chat_session(activities)
        
        # 3. Query specific data point (Avg HR of first run)
        query = "What was my average heart rate in the activity named 'Morning Interval Run'?"
        print(f"User Query: {query}")
        
        try:
            response = chat_session.send_message(query)
            response_text = response.text
            print(f"LLM Response: {response_text}")
            
            # 4. Assertions
            self.assertIn("145", response_text, f"LLM failed to identify average HR (145) from context. Response: {response_text}")
            self.assertTrue(
                "Morning Interval Run" in response_text or "12345" in response_text or "activity" in response_text.lower(),
                "LLM response did not reference the activity correctly."
            )
            
        except Exception as e:
            self.fail(f"LLM communication failed: {e}")

    def test_llm_out_of_bounds_query_handling(self):
        """
        Test 2: Verifies that the LLM adheres to system instructions by 
        refusing to answer questions unrelated to the Garmin data.
        """
        print(f"\nRunning Test 2: LLM Out-of-bounds Query Handling")
        
        garmin_client = GarminClient()
        activities = garmin_client.load_from_file(self.data_file)
        
        llm_client = LLMClient()
        chat_session = llm_client.create_chat_session(activities)
        
        # Query unrelated to running data
        query = "What is the capital of France and what is the weather there?"
        print(f"User Query: {query}")
        
        try:
            response = chat_session.send_message(query)
            response_text = response.text.lower()
            print(f"LLM Response: {response_text}")
            
            # Check if the model indicates the info is not in the data per instructions
            refusal_keywords = ["not available", "not in the data", "don't have info", "cannot answer", "only", "running"]
            self.assertTrue(
                any(keyword in response_text for keyword in refusal_keywords),
                f"LLM answered an out-of-bounds query instead of adhering to constraints. Response: {response_text}"
            )
                
        except Exception as e:
            self.fail(f"LLM communication failed: {e}")

if __name__ == "__main__":
    unittest.main()