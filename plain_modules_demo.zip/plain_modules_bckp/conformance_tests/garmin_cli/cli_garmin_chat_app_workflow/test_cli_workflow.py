import unittest
import subprocess
import os
import sys
import time

class TestGarminCliWorkflow(unittest.TestCase):
    """
    Conformance tests for the Garmin Chat CLI application.
    Tests verify the CLI entry point, environment variable handling, and workflow sequencing.
    """

    def setUp(self):
        self.python_exe = sys.executable
        self.script_path = "garmin_chat.py"
        self.base_dir = os.getcwd()
        self.data_file = "garmin_data.json"
        self.session_dir = ".test_garmin_session"
        
        # Clean up from previous potential failed runs
        self._cleanup()

    def tearDown(self):
        self._cleanup()

    def _cleanup(self):
        """Remove temporary test artifacts."""
        if os.path.exists(self.data_file):
            os.remove(self.data_file)
        if os.path.exists(self.session_dir):
            import shutil
            shutil.rmtree(self.session_dir, ignore_errors=True)

    def run_cli(self, inputs=None, env_vars=None, timeout=60, clear_env=False):
        """Helper to run the CLI with specific inputs and environment."""
        if clear_env:
            # Start with a near-empty environment to avoid inheritance of real credentials
            test_env = {"PATH": os.environ.get("PATH", ""), "PYTHONPATH": self.base_dir}
        else:
            test_env = os.environ.copy()

        if env_vars:
            test_env.update(env_vars)
            
        # Force a fresh session directory for every test run to prevent cache bypass
        # Note: Implementation of GarminClient must support session_dir if we passed it, 
        # but here we rely on the implementation reading it or just not finding the default one.
        # Since the code uses ".garmin_session" by default, we ensure it's not there.
        if os.path.exists(".garmin_session"):
            import shutil
            shutil.rmtree(".garmin_session", ignore_errors=True)

        process = subprocess.Popen(
            [self.python_exe, self.script_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=test_env,
            cwd=self.base_dir
        )
        
        try:
            stdout, stderr = process.communicate(input=inputs, timeout=timeout)
            return process.returncode, stdout, stderr
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            return -1, stdout, stderr

    def test_missing_env_vars_garmin(self):
        """Test 1: Verify error when Garmin credentials are missing."""
        print("\nRunning: test_missing_env_vars_garmin")
        
        # Use clear_env=True to ensure no credentials leak from the host system
        rc, stdout, stderr = self.run_cli(env_vars={}, clear_env=True)
        
        combined_output = stdout + stderr
        print(f"STDOUT: {stdout}")
        print(f"STDERR: {stderr}")
        
        self.assertNotEqual(rc, 0, "Application should exit with non-zero status when Garmin env vars are missing.")
        self.assertIn("GARMIN_EMAIL and GARMIN_PASSWORD environment variables must be set", combined_output)

    def test_missing_env_vars_llm(self):
        """Test 2: Verify error when Google API Key is missing after fetch phase."""
        print("\nRunning: test_missing_env_vars_llm")
        # Requires valid Garmin credentials to pass the first phase
        email = os.getenv("GARMIN_EMAIL")
        password = os.getenv("GARMIN_PASSWORD")
        if not email or not password:
            self.skipTest("Skipping test: GARMIN_EMAIL/PASSWORD not set in environment.")

        # Construct env with Garmin but without Google
        env_vars = {
            "GARMIN_EMAIL": email,
            "GARMIN_PASSWORD": password
        }
        
        # Provide 'exit' in case it reaches the loop unexpectedly
        rc, stdout, stderr = self.run_cli(inputs="exit\n", env_vars=env_vars, timeout=120, clear_env=True)
        
        combined_output = stdout + stderr
        print(f"STDOUT: {stdout}")
        print(f"STDERR: {stderr}")
        
        # Should complete fetch but fail at LLM initialization
        self.assertIn("garmin_data.json", combined_output)
        self.assertNotEqual(rc, 0, "Application should exit with non-zero status when GOOGLE_API_KEY is missing.")
        self.assertIn("GOOGLE_API_KEY environment variable is not set", combined_output)

    def test_cli_graceful_exit(self):
        """Test 3: Verify 'exit' command terminates the chat loop gracefully."""
        print("\nRunning: test_cli_graceful_exit")
        if not all(os.getenv(v) for v in ["GARMIN_EMAIL", "GARMIN_PASSWORD", "GOOGLE_API_KEY"]):
            self.skipTest("Skipping test: Missing required API credentials.")

        rc, stdout, stderr = self.run_cli(inputs="exit\n", timeout=150)
        
        print(f"STDOUT: {stdout}")
        
        self.assertEqual(rc, 0, f"Application failed with code {rc}. Error: {stderr}")
        self.assertIn("Closing chat", stdout)
        self.assertIn("Keep up the training", stdout)

    def test_cli_full_workflow_execution(self):
        """Test 4: Verify sequential workflow execution and basic interaction."""
        print("\nRunning: test_cli_full_workflow_execution")
        if not all(os.getenv(v) for v in ["GARMIN_EMAIL", "GARMIN_PASSWORD", "GOOGLE_API_KEY"]):
            self.skipTest("Skipping test: Missing required API credentials.")

        # Ask a simple question then exit
        inputs = "How many runs did I do?\nexit\n"
        rc, stdout, stderr = self.run_cli(inputs=inputs, timeout=180)
        
        print(f"STDOUT: {stdout}")
        
        # Verify sequence
        self.assertIn("Garmin Data Fetch Workflow Started", stdout)
        self.assertIn("Saving data to garmin_data.json", stdout)
        self.assertIn("Garmin AI Coach Chat Workflow Started", stdout)
        self.assertIn("Coach:", stdout, "LLM response header not found.")
        self.assertEqual(rc, 0, f"Full workflow failed. Stderr: {stderr}")

if __name__ == "__main__":
    unittest.main()