import os
import json
import unittest
import subprocess
import sys
from typing import List

# Constants for testing
TEST_DATA_FILE = "test_garmin_data.json"
CORRUPT_DATA_FILE = "corrupt_garmin_data.json"
NON_EXISTENT_FILE = "ghost_file.json"

def run_client_action(action_code: str):
    """
    Executes a snippet of code using the project's environment 
    to test the functionality of garmin.client.GarminClient.
    """
    # We use the python interpreter to run the logic to ensure we test the 
    # implementation as it would run in production.
    cmd = [
        sys.executable, "-c", 
        f"from src.garmin.client import GarminClient; {action_code}"
    ]
    # Ensure PYTHONPATH is set so src is discoverable
    env = os.environ.copy()
    env["PYTHONPATH"] = os.getcwd()
    
    return subprocess.run(cmd, capture_output=True, text=True, env=env)

class TestSerializationConformance(unittest.TestCase):
    def tearDown(self):
        """Cleanup generated test files after each test."""
        for f in [TEST_DATA_FILE, CORRUPT_DATA_FILE]:
            if os.path.exists(f):
                os.remove(f)

    def test_verify_file_serialization_and_persistence(self):
        """
        Test 1: VerifyFileSerializationAndPersistence
        Fetches real data, saves it, and verifies the structure of the saved JSON.
        """
        print("Starting Test 1: Serialization and Persistence...")
        
        # Logic: Initialize client, fetch (real API call), and save
        action = (
            f"client = GarminClient(); "
            f"client.login(); "
            f"activities = client.fetch_running_activities(days=1); "
            f"client.save_to_file(activities, '{TEST_DATA_FILE}')"
        )
        
        result = run_client_action(action)
        print(f"STDOUT: {result.stdout}")
        print(f"STDERR: {result.stderr}")
        
        self.assertEqual(result.returncode, 0, f"Client failed to fetch/save activities: {result.stderr}")
        self.assertTrue(os.path.exists(TEST_DATA_FILE), f"File {TEST_DATA_FILE} was not created")

        # Verify content structure manually
        with open(TEST_DATA_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        self.assertIsInstance(data, list, "Saved data should be a JSON list")
        if len(data) > 0:
            item = data[0]
            mandatory_fields = [
                "activityId", "activityName", "activityType", 
                "distance", "duration", "laps"
            ]
            for field in mandatory_fields:
                self.assertIn(field, item, f"Missing field {field} in saved activity")
                
            if item["laps"]:
                lap = item["laps"][0]
                lap_fields = ["lapNumber", "distance", "duration", "averageSpeed"]
                for l_field in lap_fields:
                    self.assertIn(l_field, lap, f"Missing field {l_field} in lap data")

    def test_verify_file_overwrite_behavior(self):
        """
        Test 2: VerifyFileOverwriteBehavior
        Ensures that saving new data completely replaces old file content.
        """
        print("Starting Test 2: Overwrite Behavior...")
        
        # Pre-create a dummy file with placeholder
        placeholder = {"dummy": "data", "id": 999}
        with open(TEST_DATA_FILE, 'w') as f:
            json.dump([placeholder], f)

        # Run save action again
        action = (
            f"client = GarminClient(); "
            f"client.login(); "
            f"activities = client.fetch_running_activities(days=1); "
            f"client.save_to_file(activities, '{TEST_DATA_FILE}')"
        )
        
        result = run_client_action(action)
        self.assertEqual(result.returncode, 0)
        
        with open(TEST_DATA_FILE, 'r') as f:
            new_data = json.load(f)
        
        # Check that placeholder is gone
        for activity in new_data:
            self.assertNotIn("dummy", activity, "Old placeholder data still exists in file")

    def test_verify_load_error_handling(self):
        """
        Test 3: VerifyLoadErrorHandling
        Verifies behavior when loading non-existent or corrupted files.
        """
        print("Starting Test 3: Error Handling...")

        # Case A: Non-existent file
        action_missing = f"client = GarminClient(); client.load_from_file('{NON_EXISTENT_FILE}')"
        result_missing = run_client_action(action_missing)
        
        self.assertNotEqual(result_missing.returncode, 0, "Application should exit on missing file")
        self.assertTrue("does not exist" in result_missing.stdout or "does not exist" in result_missing.stderr)

        # Case B: Corrupted JSON
        with open(CORRUPT_DATA_FILE, 'w') as f:
            f.write("{ 'invalid': json, [brackets_unclosed ]")
        
        action_corrupt = f"client = GarminClient(); client.load_from_file('{CORRUPT_DATA_FILE}')"
        result_corrupt = run_client_action(action_corrupt)
        
        self.assertNotEqual(result_corrupt.returncode, 0, "Application should exit on corrupted JSON")
        self.assertTrue("Failed to parse JSON" in result_corrupt.stdout or "JSONDecodeError" in result_corrupt.stderr)

if __name__ == "__main__":
    unittest.main()